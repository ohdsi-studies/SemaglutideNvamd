#Please refer to this: https://github.com/OHDSI/DbDiagnostics/tree/main?tab=readme-ov-file

# first set your output location
outputFolder <- "your output folder"

#Indication
indication_t2dm <- read.csv("./Downloads/new_t2dm_includedConcepts.csv") # condition, measurement, drug, observation

#Target
target_concepts <- read.csv("./Downloads/Target_concepts.csv") #drug

#Outcome
outcome11 <- read.csv("./Downloads/Outcome11.csv") #condition, procedure, observation

# create the settings for the study

# This study compares second-line diabetes medications in T2DM patients, examining their effects on 12 ocular outcomes including NVAMD, uveitis, and retinal inflammation

analysisSettings1 <- DbDiagnostics::createDataDiagnosticsSettings(
  analysisId = 1,
  analysisName = "Semaglutide_NVAMD11",
  minAge = 18,
  maxAge = 100,
  genderConceptIds = c(8507,8532),
  raceConceptIds = NULL, 
  ethnicityConceptIds = NULL,
  studyStartDate = "201701", 
  studyEndDate = "202412", 
  requiredDurationDays = 365,# 1 year observation period
  requiredDomains = c("person", "condition","drug",'measurement','observation','procedure'),
  desiredDomains = NULL,
  requiredVisits = NULL,
  desiredVisits = c("OP"), 
  targetName = "Semaglutide_Dulaglutide_Exenatide_Empagliflozin_Sitagliptin_Glipizide",
  targetConceptIds = target_concepts$Concept_ID,
  #comparatorName = "NULL",
  #comparatorConceptIds = NULL,
  outcomeName = "Panuveitis (excluding intraocular surgery)", #outcomeName11
  outcomeConceptIds = outcome11$Id, #outcomeConceptIds11
  indicator = "T2DM", 
  indicatorIds = indication_t2dm$Concept_ID)

# IMPORTANT! You need to pass a list of all settings to the executeDbDiagnostics function. It is common for this function to 
# be used to evaluate multiple studies at one time so you need to add them all to one list like below, even if you only have
# one analysis.

settingsList <- list(analysisSettings1)

# Run the executeDbDiagnostics function
dbProfileConnectionDetails <- DatabaseConnector::createConnectionDetails(dbms = "",
                                                                         user = ,
                                                                         password = ,
                                                                         server = "your server",
                                                                         port = ,
                                                                         extraSettings = )

dbDiagnosticResults <- DbDiagnostics::executeDbDiagnostics(
  connectionDetails = dbProfileConnectionDetails,
  resultsDatabaseSchema = "",
  resultsTableName = "",
  outputFolder = outputFolder,
  dataDiagnosticsSettingsList = settingsList)

#This will write an output csv file and a summary csv file with all results.

#The summary csv file will show each analysis and each database available.The column 'total_fails' give a number of the total required elements for an analysis that are unavailable in each database. Any database with a 'total_fails' value of zero indicates that the database is a potential candidate to run the full study as specified in the analysis settings.Any value in the 'total_fails' column >= 1 indicates that the database is not a good candidated to run the full study. The additional columns in the summary file detail the exact items in the settings list that did not pass diagnostics. The results csv file provides all information including the percentage of people in the database that meet each individual criteria in the settings list and what thresholds were used to determine failures.

